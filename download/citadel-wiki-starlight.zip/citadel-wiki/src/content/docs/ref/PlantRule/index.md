---
title: 'PlantRule type'
description: 'A plant on a column'
---

A plant on a column. Each column takes at most one: a rule that holds is tried with its `chance` (1), in the order of the list.

## Fields

| Field | Purpose |
| --- | --- |
| [`plantRule.block: BlockPick ?`](/ref/PlantRule/block/) |  |
| [`plantRule.blocks: { BlockPick }?`](/ref/PlantRule/blocks/) | The blocks from the foot up, in place of `block`: a two-block flower. |
| [`plantRule.tip: BlockPick ?`](/ref/PlantRule/tip/) | With `height`, the block on top of a plant that grows. |
| [`plantRule.height: (Field \| number)?`](/ref/PlantRule/height/) | How many blocks a plant that grows is tall: `block` repeats. |
| [`plantRule.chance: (Field \| number)?`](/ref/PlantRule/chance/) |  |
| [`plantRule.biome: string ?`](/ref/PlantRule/biome/) |  |
| [`plantRule.when: (Field \| number)?`](/ref/PlantRule/when/) |  |
| [`plantRule.afloat: boolean ?`](/ref/PlantRule/afloat/) | On the water over a column, not on its ground. |
| [`plantRule.sink: number ?`](/ref/PlantRule/sink/) | Blocks to stand lower: 1 is in the ground, or in the top of the water. |
| [`plantRule.clear: number ?`](/ref/PlantRule/clear/) | Blocks of water to keep clear over a plant that grows in it. |
| [`plantRule.place: ("top" \| "floor" \| "ceiling" \| "wall")?`](/ref/PlantRule/place/) | Where it goes: "top" (the default), or in the caves `density` or `carvers` dig: "floor", "ceiling" (it hangs down: `tip` is lowest) or "wall" (one block; `{wall}` in its name is the side the rock is on, `{facing}` the side away). One plant on each floor and each ceiling of a cave, and in each wall block. `when` and `chance` are read at the air block it starts in. |
| [`plantRule.y: { number }?`](/ref/PlantRule/y/) | `{ low, high }`: the y it may start at. |
