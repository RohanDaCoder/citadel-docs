---
title: 'Ink type'
description: 'Anywhere a colour is asked for, every spelling works: a color value, a name, or hex ("#ff8800")'
---

Anywhere a colour is asked for, every spelling works: a `color` value, a name, or hex ("#ff8800"). A name nobody has is an error that says the nearest. A client from 1.16 gets the exact tone in text and an older one the nearest name it has.

[`Color`](/ref/Color/) | [`ColorName`](/ref/ColorName/) | `string`
